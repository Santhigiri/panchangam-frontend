<?php

declare(strict_types=1);

return [
    'routes' => [
        // Page routes
        ['name' => 'page#index', 'url' => '/', 'verb' => 'GET'],
        ['name' => 'page#quickAdd', 'url' => '/quick-add', 'verb' => 'GET'],
        
        // Account routes
        ['name' => 'account#index', 'url' => '/api/accounts', 'verb' => 'GET'],
        ['name' => 'account#show', 'url' => '/api/accounts/{id}', 'verb' => 'GET'],
        ['name' => 'account#create', 'url' => '/api/accounts', 'verb' => 'POST'],
        ['name' => 'account#update', 'url' => '/api/accounts/{id}', 'verb' => 'PUT'],
        ['name' => 'account#destroy', 'url' => '/api/accounts/{id}', 'verb' => 'DELETE'],
        ['name' => 'account#summary', 'url' => '/api/accounts/summary', 'verb' => 'GET'],
        ['name' => 'account#getBalanceHistory', 'url' => '/api/accounts/{id}/balance-history', 'verb' => 'GET'],
        ['name' => 'account#reconcile', 'url' => '/api/accounts/{id}/reconcile', 'verb' => 'POST'],
        ['name' => 'account#completeReconciliation', 'url' => '/api/accounts/{id}/reconcile/complete', 'verb' => 'POST'],

        // Statement reconciliation sessions
        ['name' => 'reconciliation#getSession', 'url' => '/api/accounts/{id}/reconciliation/session', 'verb' => 'GET'],
        ['name' => 'reconciliation#start', 'url' => '/api/accounts/{id}/reconciliation/session', 'verb' => 'POST'],
        ['name' => 'reconciliation#update', 'url' => '/api/accounts/{id}/reconciliation/session', 'verb' => 'PUT'],
        ['name' => 'reconciliation#cancel', 'url' => '/api/accounts/{id}/reconciliation/session', 'verb' => 'DELETE'],
        ['name' => 'reconciliation#tick', 'url' => '/api/accounts/{id}/reconciliation/tick', 'verb' => 'POST'],
        ['name' => 'reconciliation#complete', 'url' => '/api/accounts/{id}/reconciliation/complete', 'verb' => 'POST'],
        ['name' => 'reconciliation#history', 'url' => '/api/accounts/{id}/reconciliation/history', 'verb' => 'GET'],
        ['name' => 'account#reveal', 'url' => '/api/accounts/{id}/reveal', 'verb' => 'GET'],

        // Interest accrual routes
        ['name' => 'account#getInterestDetails', 'url' => '/api/accounts/{id}/interest', 'verb' => 'GET'],
        ['name' => 'account#getInterestRates', 'url' => '/api/accounts/{id}/interest-rates', 'verb' => 'GET'],
        ['name' => 'account#addInterestRate', 'url' => '/api/accounts/{id}/interest-rates', 'verb' => 'POST'],
        ['name' => 'account#deleteInterestRate', 'url' => '/api/accounts/{id}/interest-rates/{rateId}', 'verb' => 'DELETE'],

        // Investment valuation routes
        ['name' => 'account#getValuation', 'url' => '/api/accounts/{id}/valuation', 'verb' => 'GET'],

        // Account validation routes
        ['name' => 'account#validateIban', 'url' => '/api/accounts/validate/iban', 'verb' => 'POST'],
        ['name' => 'account#validateRoutingNumber', 'url' => '/api/accounts/validate/routing-number', 'verb' => 'POST'],
        ['name' => 'account#validateSortCode', 'url' => '/api/accounts/validate/sort-code', 'verb' => 'POST'],
        ['name' => 'account#validateSwiftBic', 'url' => '/api/accounts/validate/swift-bic', 'verb' => 'POST'],
        ['name' => 'account#getBankingInstitutions', 'url' => '/api/accounts/banking-institutions', 'verb' => 'GET'],
        ['name' => 'account#getBankingFieldRequirements', 'url' => '/api/accounts/banking-requirements/{currency}', 'verb' => 'GET'],
        
        // Transaction routes
        // Note: Specific routes MUST come before generic {id} routes to avoid mismatched routing
        ['name' => 'transaction#index', 'url' => '/api/transactions', 'verb' => 'GET'],
        ['name' => 'transaction#create', 'url' => '/api/transactions', 'verb' => 'POST'],
        ['name' => 'transaction#search', 'url' => '/api/transactions/search', 'verb' => 'GET'],
        ['name' => 'transaction#uncategorized', 'url' => '/api/transactions/uncategorized', 'verb' => 'GET'],
        ['name' => 'transaction#bulkCategorize', 'url' => '/api/transactions/bulk-categorize', 'verb' => 'POST'],
        ['name' => 'transaction#bulkMatch', 'url' => '/api/transactions/bulk-match', 'verb' => 'POST'],
        ['name' => 'transaction#scanMatches', 'url' => '/api/transactions/scan-matches', 'verb' => 'GET'],
        ['name' => 'transaction#bulkLink', 'url' => '/api/transactions/bulk-link', 'verb' => 'POST'],
        ['name' => 'transaction#bulkDelete', 'url' => '/api/transactions/bulk-delete', 'verb' => 'POST'],
        ['name' => 'transaction#bulkReconcile', 'url' => '/api/transactions/bulk-reconcile', 'verb' => 'POST'],
        ['name' => 'transaction#bulkEdit', 'url' => '/api/transactions/bulk-edit', 'verb' => 'POST'],
        ['name' => 'transaction#duplicates', 'url' => '/api/transactions/duplicates', 'verb' => 'GET'],
        ['name' => 'transaction#show', 'url' => '/api/transactions/{id}', 'verb' => 'GET'],
        ['name' => 'transaction#update', 'url' => '/api/transactions/{id}', 'verb' => 'PUT'],
        ['name' => 'transaction#destroy', 'url' => '/api/transactions/{id}', 'verb' => 'DELETE'],
        ['name' => 'transaction#getMatches', 'url' => '/api/transactions/{id}/matches', 'verb' => 'GET'],
        ['name' => 'transaction#link', 'url' => '/api/transactions/{id}/link/{targetId}', 'verb' => 'POST'],
        ['name' => 'transaction#unlink', 'url' => '/api/transactions/{id}/link', 'verb' => 'DELETE'],
        ['name' => 'transaction#getSplits', 'url' => '/api/transactions/{id}/splits', 'verb' => 'GET'],
        ['name' => 'transaction#split', 'url' => '/api/transactions/{id}/splits', 'verb' => 'POST'],
        ['name' => 'transaction#unsplit', 'url' => '/api/transactions/{id}/splits', 'verb' => 'DELETE'],
        ['name' => 'transaction#updateSplit', 'url' => '/api/transactions/{id}/splits/{splitId}', 'verb' => 'PUT'],

        // Transaction tag routes
        ['name' => 'transaction#getTags', 'url' => '/api/transactions/{id}/tags', 'verb' => 'GET'],
        ['name' => 'transaction#setTags', 'url' => '/api/transactions/{id}/tags', 'verb' => 'PUT'],
        ['name' => 'transaction#clearTags', 'url' => '/api/transactions/{id}/tags', 'verb' => 'DELETE'],

        // Transaction receipt attachments
        ['name' => 'attachment#counts', 'url' => '/api/attachments/transaction-ids', 'verb' => 'GET'],
        ['name' => 'attachment#index', 'url' => '/api/transactions/{id}/attachments', 'verb' => 'GET'],
        ['name' => 'attachment#attach', 'url' => '/api/transactions/{id}/attachments', 'verb' => 'POST'],
        ['name' => 'attachment#upload', 'url' => '/api/transactions/{id}/attachments/upload', 'verb' => 'POST'],
        ['name' => 'attachment#detach', 'url' => '/api/transactions/{id}/attachments/{attachmentId}', 'verb' => 'DELETE'],

        // Category routes - specific paths before {id} wildcard
        ['name' => 'category#index', 'url' => '/api/categories', 'verb' => 'GET'],
        ['name' => 'category#tree', 'url' => '/api/categories/tree', 'verb' => 'GET'],
        ['name' => 'category#allSpending', 'url' => '/api/categories/spending', 'verb' => 'GET'],
        ['name' => 'category#transactionCounts', 'url' => '/api/categories/transaction-counts', 'verb' => 'GET'],
        ['name' => 'category#recurringBudgets', 'url' => '/api/categories/recurring-budgets', 'verb' => 'GET'],
        ['name' => 'category#create', 'url' => '/api/categories', 'verb' => 'POST'],
        ['name' => 'category#details', 'url' => '/api/categories/{id}/details', 'verb' => 'GET'],
        ['name' => 'category#transactions', 'url' => '/api/categories/{id}/transactions', 'verb' => 'GET'],
        ['name' => 'category#show', 'url' => '/api/categories/{id}', 'verb' => 'GET'],
        ['name' => 'category#update', 'url' => '/api/categories/{id}', 'verb' => 'PUT'],
        ['name' => 'category#destroy', 'url' => '/api/categories/{id}', 'verb' => 'DELETE'],

        // Budget snapshot routes
        ['name' => 'category#snapshotMonths', 'url' => '/api/budget-snapshots', 'verb' => 'GET'],
        ['name' => 'category#effectiveBudgets', 'url' => '/api/budget-snapshots/{month}/budgets', 'verb' => 'GET'],
        ['name' => 'category#createSnapshot', 'url' => '/api/budget-snapshots/{month}', 'verb' => 'POST'],
        ['name' => 'category#deleteSnapshot', 'url' => '/api/budget-snapshots/{month}', 'verb' => 'DELETE'],
        ['name' => 'category#updateSnapshotBudget', 'url' => '/api/budget-snapshots/{month}/categories/{categoryId}', 'verb' => 'PUT'],

        // Tag Set routes
        ['name' => 'tagSet#index', 'url' => '/api/tag-sets', 'verb' => 'GET'],
        ['name' => 'tagSet#create', 'url' => '/api/tag-sets', 'verb' => 'POST'],
        ['name' => 'tagSet#show', 'url' => '/api/tag-sets/{id}', 'verb' => 'GET'],
        ['name' => 'tagSet#update', 'url' => '/api/tag-sets/{id}', 'verb' => 'PUT'],
        ['name' => 'tagSet#destroy', 'url' => '/api/tag-sets/{id}', 'verb' => 'DELETE'],

        // Tag routes (nested under tag sets)
        ['name' => 'tagSet#getTags', 'url' => '/api/tag-sets/{tagSetId}/tags', 'verb' => 'GET'],
        ['name' => 'tagSet#createTag', 'url' => '/api/tag-sets/{tagSetId}/tags', 'verb' => 'POST'],
        ['name' => 'tagSet#updateTag', 'url' => '/api/tag-sets/{tagSetId}/tags/{tagId}', 'verb' => 'PUT'],
        ['name' => 'tagSet#destroyTag', 'url' => '/api/tag-sets/{tagSetId}/tags/{tagId}', 'verb' => 'DELETE'],

        // Global tag routes (flat tags, not bound to tag sets)
        ['name' => 'tagSet#getGlobalTags', 'url' => '/api/tags/global', 'verb' => 'GET'],
        ['name' => 'tagSet#createGlobalTag', 'url' => '/api/tags/global', 'verb' => 'POST'],
        ['name' => 'tagSet#updateGlobalTag', 'url' => '/api/tags/global/{tagId}', 'verb' => 'PUT'],
        ['name' => 'tagSet#destroyGlobalTag', 'url' => '/api/tags/global/{tagId}', 'verb' => 'DELETE'],

        // Import routes
        ['name' => 'import#upload', 'url' => '/api/import/upload', 'verb' => 'POST'],
        ['name' => 'import#preview', 'url' => '/api/import/preview', 'verb' => 'POST'],
        ['name' => 'import#process', 'url' => '/api/import/process', 'verb' => 'POST'],
        ['name' => 'import#execute', 'url' => '/api/import/execute', 'verb' => 'POST'],
        ['name' => 'import#rollback', 'url' => '/api/import/rollback/{importId}', 'verb' => 'POST'],
        ['name' => 'import#history', 'url' => '/api/import/history', 'verb' => 'GET'],
        ['name' => 'import#templates', 'url' => '/api/import/templates', 'verb' => 'GET'],

        // User-saved import template routes (reusable CSV column mappings)
        ['name' => 'importTemplate#index', 'url' => '/api/import-templates', 'verb' => 'GET'],
        ['name' => 'importTemplate#show', 'url' => '/api/import-templates/{id}', 'verb' => 'GET'],
        ['name' => 'importTemplate#create', 'url' => '/api/import-templates', 'verb' => 'POST'],
        ['name' => 'importTemplate#update', 'url' => '/api/import-templates/{id}', 'verb' => 'PUT'],
        ['name' => 'importTemplate#destroy', 'url' => '/api/import-templates/{id}', 'verb' => 'DELETE'],

        // Import rules routes (also used as general categorization rules)
        ['name' => 'importRule#index', 'url' => '/api/import-rules', 'verb' => 'GET'],
        ['name' => 'importRule#show', 'url' => '/api/import-rules/{id}', 'verb' => 'GET'],
        ['name' => 'importRule#create', 'url' => '/api/import-rules', 'verb' => 'POST'],
        ['name' => 'importRule#update', 'url' => '/api/import-rules/{id}', 'verb' => 'PUT'],
        ['name' => 'importRule#destroy', 'url' => '/api/import-rules/{id}', 'verb' => 'DELETE'],
        ['name' => 'importRule#test', 'url' => '/api/import-rules/test', 'verb' => 'POST'],
        ['name' => 'importRule#testUnsaved', 'url' => '/api/import-rules/test-unsaved', 'verb' => 'POST'],
        ['name' => 'importRule#preview', 'url' => '/api/import-rules/preview', 'verb' => 'POST'],
        ['name' => 'importRule#apply', 'url' => '/api/import-rules/apply', 'verb' => 'POST'],
        ['name' => 'importRule#migrate', 'url' => '/api/import-rules/{id}/migrate', 'verb' => 'POST'],
        ['name' => 'importRule#migrateAll', 'url' => '/api/import-rules/migrate-all', 'verb' => 'POST'],
        ['name' => 'importRule#validateCriteria', 'url' => '/api/import-rules/validate-criteria', 'verb' => 'POST'],

        // Forecast routes
        ['name' => 'forecast#live', 'url' => '/api/forecast/live', 'verb' => 'GET'],
        ['name' => 'forecast#generate', 'url' => '/api/forecast/generate', 'verb' => 'POST'],
        ['name' => 'forecast#enhanced', 'url' => '/api/forecast/enhanced', 'verb' => 'POST'],
        ['name' => 'forecast#export', 'url' => '/api/forecast/export', 'verb' => 'POST'],
        ['name' => 'forecast#cashflow', 'url' => '/api/forecast/cashflow', 'verb' => 'GET'],
        ['name' => 'forecast#trends', 'url' => '/api/forecast/trends', 'verb' => 'GET'],

        // Bills routes - specific paths before {id} wildcard
        ['name' => 'bill#index', 'url' => '/api/bills', 'verb' => 'GET'],
        ['name' => 'bill#create', 'url' => '/api/bills', 'verb' => 'POST'],
        ['name' => 'bill#upcoming', 'url' => '/api/bills/upcoming', 'verb' => 'GET'],
        ['name' => 'bill#dueThisMonth', 'url' => '/api/bills/due-this-month', 'verb' => 'GET'],
        ['name' => 'bill#overdue', 'url' => '/api/bills/overdue', 'verb' => 'GET'],
        ['name' => 'bill#summary', 'url' => '/api/bills/summary', 'verb' => 'GET'],
        ['name' => 'bill#statusForMonth', 'url' => '/api/bills/status', 'verb' => 'GET'],
        ['name' => 'bill#detect', 'url' => '/api/bills/detect', 'verb' => 'GET'],
        ['name' => 'bill#suggestions', 'url' => '/api/bills/suggestions', 'verb' => 'GET'],
        ['name' => 'bill#dismissSuggestion', 'url' => '/api/bills/suggestions/dismiss', 'verb' => 'POST'],
        ['name' => 'bill#createFromDetected', 'url' => '/api/bills/create-from-detected', 'verb' => 'POST'],
        ['name' => 'bill#annualOverview', 'url' => '/api/bills/annual-overview', 'verb' => 'GET'],
        ['name' => 'bill#exportCalendar', 'url' => '/api/bills/export-calendar', 'verb' => 'POST'],

        // Bills calendar feed (ICS): public token-authenticated feed + token management
        ['name' => 'calendarFeed#billsIcs', 'url' => '/feed/bills.ics', 'verb' => 'GET'],
        ['name' => 'calendarFeed#info', 'url' => '/api/calendar-feed', 'verb' => 'GET'],
        ['name' => 'calendarFeed#regenerate', 'url' => '/api/calendar-feed/regenerate', 'verb' => 'POST'],
        ['name' => 'bill#show', 'url' => '/api/bills/{id}', 'verb' => 'GET'],
        ['name' => 'bill#update', 'url' => '/api/bills/{id}', 'verb' => 'PUT'],
        ['name' => 'bill#destroy', 'url' => '/api/bills/{id}', 'verb' => 'DELETE'],
        ['name' => 'bill#findMatchingTransactions', 'url' => '/api/bills/{id}/matching-transactions', 'verb' => 'GET'],
        ['name' => 'bill#markPaid', 'url' => '/api/bills/{id}/paid', 'verb' => 'POST'],
        ['name' => 'bill#skipPayment', 'url' => '/api/bills/{id}/skip', 'verb' => 'POST'],
        ['name' => 'bill#undoSkip', 'url' => '/api/bills/{id}/undo-skip', 'verb' => 'POST'],
        ['name' => 'bill#undoPaid', 'url' => '/api/bills/{id}/undo-paid', 'verb' => 'POST'],

        // Savings Goals routes
        ['name' => 'goals#index', 'url' => '/api/savings-goals', 'verb' => 'GET'],
        ['name' => 'goals#show', 'url' => '/api/savings-goals/{id}', 'verb' => 'GET'],
        ['name' => 'goals#create', 'url' => '/api/savings-goals', 'verb' => 'POST'],
        ['name' => 'goals#update', 'url' => '/api/savings-goals/{id}', 'verb' => 'PUT'],
        ['name' => 'goals#destroy', 'url' => '/api/savings-goals/{id}', 'verb' => 'DELETE'],
        ['name' => 'goals#progress', 'url' => '/api/savings-goals/{id}/progress', 'verb' => 'GET'],
        ['name' => 'goals#forecast', 'url' => '/api/savings-goals/{id}/forecast', 'verb' => 'GET'],

        // Net Worth routes
        ['name' => 'netWorth#current', 'url' => '/api/net-worth/current', 'verb' => 'GET'],
        ['name' => 'netWorth#snapshots', 'url' => '/api/net-worth/snapshots', 'verb' => 'GET'],
        ['name' => 'netWorth#createSnapshot', 'url' => '/api/net-worth/snapshots', 'verb' => 'POST'],
        ['name' => 'netWorth#destroySnapshot', 'url' => '/api/net-worth/snapshots/{id}', 'verb' => 'DELETE'],

        // Recurring Income routes - specific paths before {id} wildcard
        ['name' => 'recurringIncome#index', 'url' => '/api/recurring-income', 'verb' => 'GET'],
        ['name' => 'recurringIncome#create', 'url' => '/api/recurring-income', 'verb' => 'POST'],
        ['name' => 'recurringIncome#upcoming', 'url' => '/api/recurring-income/upcoming', 'verb' => 'GET'],
        ['name' => 'recurringIncome#expectedThisMonth', 'url' => '/api/recurring-income/this-month', 'verb' => 'GET'],
        ['name' => 'recurringIncome#summary', 'url' => '/api/recurring-income/summary', 'verb' => 'GET'],
        ['name' => 'recurringIncome#detect', 'url' => '/api/recurring-income/detect', 'verb' => 'GET'],
        ['name' => 'recurringIncome#createFromDetected', 'url' => '/api/recurring-income/create-from-detected', 'verb' => 'POST'],
        ['name' => 'recurringIncome#show', 'url' => '/api/recurring-income/{id}', 'verb' => 'GET'],
        ['name' => 'recurringIncome#update', 'url' => '/api/recurring-income/{id}', 'verb' => 'PUT'],
        ['name' => 'recurringIncome#destroy', 'url' => '/api/recurring-income/{id}', 'verb' => 'DELETE'],
        ['name' => 'recurringIncome#markReceived', 'url' => '/api/recurring-income/{id}/received', 'verb' => 'POST'],

        // Pension routes - specific paths before {id} wildcard
        ['name' => 'pension#index', 'url' => '/api/pensions', 'verb' => 'GET'],
        ['name' => 'pension#create', 'url' => '/api/pensions', 'verb' => 'POST'],
        ['name' => 'pension#summary', 'url' => '/api/pensions/summary', 'verb' => 'GET'],
        ['name' => 'pension#combinedProjection', 'url' => '/api/pensions/projection', 'verb' => 'GET'],
        ['name' => 'pension#show', 'url' => '/api/pensions/{id}', 'verb' => 'GET'],
        ['name' => 'pension#update', 'url' => '/api/pensions/{id}', 'verb' => 'PUT'],
        ['name' => 'pension#destroy', 'url' => '/api/pensions/{id}', 'verb' => 'DELETE'],
        ['name' => 'pension#snapshots', 'url' => '/api/pensions/{id}/snapshots', 'verb' => 'GET'],
        ['name' => 'pension#createSnapshot', 'url' => '/api/pensions/{id}/snapshots', 'verb' => 'POST'],
        ['name' => 'pension#contributions', 'url' => '/api/pensions/{id}/contributions', 'verb' => 'GET'],
        ['name' => 'pension#createContribution', 'url' => '/api/pensions/{id}/contributions', 'verb' => 'POST'],
        ['name' => 'pension#projection', 'url' => '/api/pensions/{id}/projection', 'verb' => 'GET'],
        ['name' => 'pension#destroySnapshot', 'url' => '/api/pensions/snapshots/{snapshotId}', 'verb' => 'DELETE'],
        ['name' => 'pension#destroyContribution', 'url' => '/api/pensions/contributions/{contributionId}', 'verb' => 'DELETE'],

        // Asset routes - specific paths before {id} wildcard
        ['name' => 'asset#index', 'url' => '/api/assets', 'verb' => 'GET'],
        ['name' => 'asset#create', 'url' => '/api/assets', 'verb' => 'POST'],
        ['name' => 'asset#summary', 'url' => '/api/assets/summary', 'verb' => 'GET'],
        ['name' => 'asset#combinedProjection', 'url' => '/api/assets/projection', 'verb' => 'GET'],
        ['name' => 'asset#valueHistory', 'url' => '/api/assets/value-history', 'verb' => 'GET'],
        ['name' => 'asset#show', 'url' => '/api/assets/{id}', 'verb' => 'GET'],
        ['name' => 'asset#update', 'url' => '/api/assets/{id}', 'verb' => 'PUT'],
        ['name' => 'asset#destroy', 'url' => '/api/assets/{id}', 'verb' => 'DELETE'],
        ['name' => 'asset#snapshots', 'url' => '/api/assets/{id}/snapshots', 'verb' => 'GET'],
        ['name' => 'asset#createSnapshot', 'url' => '/api/assets/{id}/snapshots', 'verb' => 'POST'],
        ['name' => 'asset#projection', 'url' => '/api/assets/{id}/projection', 'verb' => 'GET'],
        ['name' => 'asset#destroySnapshot', 'url' => '/api/assets/snapshots/{snapshotId}', 'verb' => 'DELETE'],

        // Budget Alert routes
        ['name' => 'alert#index', 'url' => '/api/alerts', 'verb' => 'GET'],
        ['name' => 'alert#status', 'url' => '/api/alerts/status', 'verb' => 'GET'],
        ['name' => 'alert#summary', 'url' => '/api/alerts/summary', 'verb' => 'GET'],

        // Debt Payoff routes
        ['name' => 'debt#index', 'url' => '/api/debts', 'verb' => 'GET'],
        ['name' => 'debt#summary', 'url' => '/api/debts/summary', 'verb' => 'GET'],
        ['name' => 'debt#payoffPlan', 'url' => '/api/debts/payoff-plan', 'verb' => 'GET'],
        ['name' => 'debt#compare', 'url' => '/api/debts/compare', 'verb' => 'GET'],
        ['name' => 'debt#progress', 'url' => '/api/debts/progress', 'verb' => 'GET'],

        // Debt Scenario routes (specific routes before {id} routes)
        ['name' => 'debt_scenario#index', 'url' => '/api/debt-scenarios', 'verb' => 'GET'],
        ['name' => 'debt_scenario#create', 'url' => '/api/debt-scenarios', 'verb' => 'POST'],
        ['name' => 'debt_scenario#compare', 'url' => '/api/debt-scenarios/compare', 'verb' => 'GET'],
        ['name' => 'debt_scenario#update', 'url' => '/api/debt-scenarios/{id}', 'verb' => 'PUT'],
        ['name' => 'debt_scenario#destroy', 'url' => '/api/debt-scenarios/{id}', 'verb' => 'DELETE'],
        ['name' => 'debt_scenario#activate', 'url' => '/api/debt-scenarios/{id}/activate', 'verb' => 'POST'],
        ['name' => 'debt_scenario#calculate', 'url' => '/api/debt-scenarios/{id}/calculate', 'verb' => 'GET'],

        // Year-over-Year Comparison routes
        ['name' => 'yearOverYear#compareMonth', 'url' => '/api/yoy/month', 'verb' => 'GET'],
        ['name' => 'yearOverYear#compareYears', 'url' => '/api/yoy/years', 'verb' => 'GET'],
        ['name' => 'yearOverYear#compareCategories', 'url' => '/api/yoy/categories', 'verb' => 'GET'],
        ['name' => 'yearOverYear#monthlyTrends', 'url' => '/api/yoy/trends', 'verb' => 'GET'],
        ['name' => 'yearOverYear#export', 'url' => '/api/yoy/export', 'verb' => 'POST'],

        // Shared Expense routes - user search
        ['name' => 'sharedExpense#searchUsers', 'url' => '/api/shared/users/search', 'verb' => 'GET'],
        // Shared Expense routes - contacts
        ['name' => 'sharedExpense#contacts', 'url' => '/api/shared/contacts', 'verb' => 'GET'],
        ['name' => 'sharedExpense#createContact', 'url' => '/api/shared/contacts', 'verb' => 'POST'],
        ['name' => 'sharedExpense#updateContact', 'url' => '/api/shared/contacts/{id}', 'verb' => 'PUT'],
        ['name' => 'sharedExpense#destroyContact', 'url' => '/api/shared/contacts/{id}', 'verb' => 'DELETE'],
        ['name' => 'sharedExpense#contactDetails', 'url' => '/api/shared/contacts/{id}/details', 'verb' => 'GET'],
        // Shared Expense routes - balances
        ['name' => 'sharedExpense#balances', 'url' => '/api/shared/balances', 'verb' => 'GET'],
        ['name' => 'sharedExpense#sharedWithMe', 'url' => '/api/shared/shared-with-me', 'verb' => 'GET'],
        ['name' => 'sharedExpense#sharedTransactionIds', 'url' => '/api/shared/transaction-ids', 'verb' => 'GET'],
        // Shared Expense routes - expense shares
        ['name' => 'sharedExpense#shareExpense', 'url' => '/api/shared/shares', 'verb' => 'POST'],
        ['name' => 'sharedExpense#splitFiftyFifty', 'url' => '/api/shared/shares/split', 'verb' => 'POST'],
        ['name' => 'sharedExpense#transactionShares', 'url' => '/api/shared/transactions/{transactionId}/shares', 'verb' => 'GET'],
        ['name' => 'sharedExpense#updateShare', 'url' => '/api/shared/shares/{id}', 'verb' => 'PUT'],
        ['name' => 'sharedExpense#markSettled', 'url' => '/api/shared/shares/{id}/settle', 'verb' => 'POST'],
        ['name' => 'sharedExpense#destroyShare', 'url' => '/api/shared/shares/{id}', 'verb' => 'DELETE'],
        // Shared Expense routes - settlements
        ['name' => 'sharedExpense#settlements', 'url' => '/api/shared/settlements', 'verb' => 'GET'],
        ['name' => 'sharedExpense#settleSelected', 'url' => '/api/shared/settle-selected', 'verb' => 'POST'],
        ['name' => 'sharedExpense#recordSettlement', 'url' => '/api/shared/settlements', 'verb' => 'POST'],
        ['name' => 'sharedExpense#settleWithContact', 'url' => '/api/shared/contacts/{contactId}/settle', 'verb' => 'POST'],
        ['name' => 'sharedExpense#destroySettlement', 'url' => '/api/shared/settlements/{id}', 'verb' => 'DELETE'],

        // Report routes
        ['name' => 'report#summary', 'url' => '/api/reports/summary', 'verb' => 'GET'],
        ['name' => 'report#summaryWithComparison', 'url' => '/api/reports/summary-comparison', 'verb' => 'GET'],
        ['name' => 'report#spending', 'url' => '/api/reports/spending', 'verb' => 'GET'],
        ['name' => 'report#income', 'url' => '/api/reports/income', 'verb' => 'GET'],
        ['name' => 'report#cashflow', 'url' => '/api/reports/cashflow', 'verb' => 'GET'],
        ['name' => 'report#budget', 'url' => '/api/reports/budget', 'verb' => 'GET'],
        ['name' => 'report#export', 'url' => '/api/reports/export', 'verb' => 'POST'],

        // Tag Report routes
        ['name' => 'report#tagDimensions', 'url' => '/api/reports/tags/dimensions', 'verb' => 'GET'],
        ['name' => 'report#tagCombinations', 'url' => '/api/reports/tags/combinations', 'verb' => 'GET'],
        ['name' => 'report#tagCrossTab', 'url' => '/api/reports/tags/crosstab', 'verb' => 'GET'],
        ['name' => 'report#tagTrends', 'url' => '/api/reports/tags/trends', 'verb' => 'GET'],
        ['name' => 'report#tagSetBreakdown', 'url' => '/api/reports/tags/breakdown', 'verb' => 'GET'],

        // Setup routes
        ['name' => 'setup#initialize', 'url' => '/api/setup/initialize', 'verb' => 'POST'],
        ['name' => 'setup#status', 'url' => '/api/setup/status', 'verb' => 'GET'],
        ['name' => 'setup#removeDuplicateCategories', 'url' => '/api/setup/remove-duplicate-categories', 'verb' => 'POST'],
        ['name' => 'setup#resetCategories', 'url' => '/api/setup/reset-categories', 'verb' => 'POST'],
        ['name' => 'setup#factoryReset', 'url' => '/api/setup/factory-reset', 'verb' => 'POST'],
        ['name' => 'setup#recalculateBalances', 'url' => '/api/setup/recalculate-balances', 'verb' => 'POST'],
        ['name' => 'setup#diagnoseData', 'url' => '/api/setup/diagnose', 'verb' => 'GET'],
        ['name' => 'setup#repairData', 'url' => '/api/setup/repair', 'verb' => 'POST'],
        ['name' => 'setup#systemInfo', 'url' => '/api/setup/system-info', 'verb' => 'GET'],

        // Settings routes - specific paths before {key} wildcard
        ['name' => 'setting#index', 'url' => '/api/settings', 'verb' => 'GET'],
        ['name' => 'setting#update', 'url' => '/api/settings', 'verb' => 'PUT'],
        ['name' => 'setting#reset', 'url' => '/api/settings/reset', 'verb' => 'POST'],
        ['name' => 'setting#options', 'url' => '/api/settings/options', 'verb' => 'GET'],
        ['name' => 'setting#show', 'url' => '/api/settings/{key}', 'verb' => 'GET'],
        ['name' => 'setting#updateKey', 'url' => '/api/settings/{key}', 'verb' => 'PUT'],
        ['name' => 'setting#destroy', 'url' => '/api/settings/{key}', 'verb' => 'DELETE'],

        // Migration routes (data export/import)
        ['name' => 'migration#export', 'url' => '/api/migration/export', 'verb' => 'GET'],
        ['name' => 'migration#preview', 'url' => '/api/migration/preview', 'verb' => 'POST'],
        ['name' => 'migration#import', 'url' => '/api/migration/import', 'verb' => 'POST'],

        // Budget sharing routes
        ['name' => 'share#outgoing', 'url' => '/api/shares/outgoing', 'verb' => 'GET'],
        ['name' => 'share#incoming', 'url' => '/api/shares/incoming', 'verb' => 'GET'],
        ['name' => 'share#pending', 'url' => '/api/shares/pending', 'verb' => 'GET'],
        ['name' => 'share#create', 'url' => '/api/shares', 'verb' => 'POST'],
        ['name' => 'share#accept', 'url' => '/api/shares/{id}/accept', 'verb' => 'POST'],
        ['name' => 'share#decline', 'url' => '/api/shares/{id}/decline', 'verb' => 'POST'],
        ['name' => 'share#revoke', 'url' => '/api/shares/{id}', 'verb' => 'DELETE'],
        ['name' => 'share#leave', 'url' => '/api/shares/{id}/leave', 'verb' => 'POST'],
        ['name' => 'share#getConfig', 'url' => '/api/shares/{id}/items', 'verb' => 'GET'],
        ['name' => 'share#updateTypeItems', 'url' => '/api/shares/{id}/items/{type}', 'verb' => 'PUT'],

        // Exchange rate routes
        ['name' => 'exchangeRate#index', 'url' => '/api/exchange-rates', 'verb' => 'GET'],
        ['name' => 'exchangeRate#convert', 'url' => '/api/exchange-rates/convert', 'verb' => 'GET'],
        ['name' => 'exchangeRate#latest', 'url' => '/api/exchange-rates/latest', 'verb' => 'GET'],
        ['name' => 'exchangeRate#refresh', 'url' => '/api/exchange-rates/refresh', 'verb' => 'POST'],
        ['name' => 'exchangeRate#setManualRate', 'url' => '/api/exchange-rates/manual', 'verb' => 'POST'],
        ['name' => 'exchangeRate#removeManualRate', 'url' => '/api/exchange-rates/manual/{currency}', 'verb' => 'DELETE'],

        // Bank Sync routes
        ['name' => 'bankSync#status', 'url' => '/api/bank-sync/status', 'verb' => 'GET'],
        ['name' => 'bankSync#providers', 'url' => '/api/bank-sync/providers', 'verb' => 'GET'],
        ['name' => 'bankSync#institutions', 'url' => '/api/bank-sync/providers/{provider}/institutions', 'verb' => 'POST'],
        ['name' => 'bankSync#connections', 'url' => '/api/bank-sync/connections', 'verb' => 'GET'],
        ['name' => 'bankSync#connect', 'url' => '/api/bank-sync/connections', 'verb' => 'POST'],
        ['name' => 'bankSync#updateConnection', 'url' => '/api/bank-sync/connections/{id}', 'verb' => 'PUT'],
        ['name' => 'bankSync#disconnect', 'url' => '/api/bank-sync/connections/{id}', 'verb' => 'DELETE'],
        ['name' => 'bankSync#sync', 'url' => '/api/bank-sync/connections/{id}/sync', 'verb' => 'POST'],
        ['name' => 'bankSync#mappings', 'url' => '/api/bank-sync/connections/{id}/mappings', 'verb' => 'GET'],
        ['name' => 'bankSync#updateMapping', 'url' => '/api/bank-sync/connections/{id}/mappings/{mappingId}', 'verb' => 'PUT'],
        ['name' => 'bankSync#refreshAccounts', 'url' => '/api/bank-sync/connections/{id}/refresh', 'verb' => 'POST'],
        ['name' => 'bankSync#reauthorize', 'url' => '/api/bank-sync/connections/{id}/reauthorize', 'verb' => 'POST'],

        // Admin settings routes
        ['name' => 'adminSetting#index', 'url' => '/api/admin/settings', 'verb' => 'GET'],
        ['name' => 'adminSetting#update', 'url' => '/api/admin/settings', 'verb' => 'PUT'],
    ],
];